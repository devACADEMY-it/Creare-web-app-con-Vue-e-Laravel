<template>
    <div class="row">
        <div class="col-md-6" v-for="(post, i) in posts" :key="i">
            <div class="card mt-4">
                <img class="card-image-top" :src="post.post_images[0].path" alt=""/>
                <div class="card-body">
                    <p class="card-text">
                        <strong>{{ post.title }}</strong><br/>
                        {{ post.body }}
                    </p>
                </div>
                <button class="btn btn-primary m-2">Scopri di più</button>
            </div>
        </div>
    </div>
</template>

<script>
  export default {
    data() {
      return {
        posts: [
          {
            id: 1,
            post_images: [
              {
                path: 'https://images.japancentre.com/recipes/pics/1489/main/jc_fresh_3_gyoza_450_300.jpg?1469705896'
              }
            ],
            title: 'Come fare i gyoza',
            body: 'Per preparare i gyoza abbiamo bisogno di...'
          },
          {
            id: 2,
            post_images: [
              {
                path: 'https://i1.wp.com/www.piccolericette.net/piccolericette/wp-content/uploads/2019/09/4075_Ravioli.jpg?resize=895%2C616&ssl=1'
              }
            ],
            title: 'Come fare i ravioli',
            body: 'Per preparare i ravioli abbiamo bisogno di...'
          },
        ]
      };
    },
    methods: {

    }
  }
</script>

<style scoped>
.card-image-top {
    height: 200px;
    width: auto;
}
</style>
