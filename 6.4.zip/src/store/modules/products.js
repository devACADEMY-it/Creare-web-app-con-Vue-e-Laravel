const state = () => ({
  all: []
});

const mutations = {
  setProducts(state, products) {
    state.all = products;
  },
  incrementProductInventory(state, { id }) {
    const product = state.all.find(item => item.id === id);
    product.inventory++;
  },
  decrementProductInventory(state, { id }) {
    const product = state.all.find(item => item.id === id);
    product.inventory--;
  },
};

const actions = {
  getAllProducts(context) {
    // get su API per i prodotti
    context.commit('setProducts', []);
  }
};

const getters = {};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters,
}
