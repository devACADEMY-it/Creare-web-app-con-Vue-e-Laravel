<template>
  <h1 class="title">CART</h1>

  <div class="columns is-multiline">
    <h1 class="title is-2">Total: {{ total }} €</h1>
    <div class="column is-12" v-for="product in cart.products" :key="product.id">
      <CartElement :product="product"></CartElement>
    </div>
  </div>
</template>

<script>
import CartElement from "./CartElement";

export default {
  components: { CartElement },
  computed: {
    total() {
      return this.cart.products.reduce((acc, currentItem) => {
        return acc + (currentItem.price * currentItem.quantity);
      }, 0);
    }
  },
  data() {
    return {
      cart: {
        products: [
          {
            "id": 1,
            "name": "donut",
            "label": "Ciambella",
            "imageSrc": "ciambella.png",
            "price": 2.5,
            "quantity": 1,
          },
          {
            "id": 2,
            "name": "coke",
            "label": "Coca in bottiglia",
            "imageSrc": "coca.png",
            "price": 3,
            "quantity": 2,
          }
        ]
      }
    }
  }
}
</script>
