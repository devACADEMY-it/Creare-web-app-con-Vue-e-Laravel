// Gestire i posts dell'applicazione

import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        posts: []
    },
    mutations: {
        setPosts(state, response) {
            state.posts = response.data.data || [];
        }
    },
    actions: {
        async getAllPosts({ commit }) {
            const response = await axios.get('/post/get_all');
            commit('setPosts', response);
        }
    }
})
