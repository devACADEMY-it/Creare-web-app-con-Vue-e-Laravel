<template>
  <h1 class="title">CART</h1>
</template>

<script>
  export default {

  }
</script>
