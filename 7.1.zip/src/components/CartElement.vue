<template>
  <article class="media">
    <figure class="media-left">
      <p class="image is-96x96">
        <img :src="getProductImage(product)">
      </p>
    </figure>
    <div class="media-content">
      <div class="content has-text-left">
        <h1 class="title is-3">{{ product.label }} x {{ product.quantity }} <small class="has-text-weight-light">{{ product.price * product.quantity }} €</small></h1>
      </div>
      <nav class="level is-mobile">
        <div class="level-left">
          <a class="level-item">
            <span class="icon is-small"><i class="fas fa-plus"></i></span>
          </a>
          <a class="level-item">
            <span class="icon is-small"><i class="fas fa-minus"></i></span>
          </a>
          <a class="level-item">
            <span class="icon is-small"><i class="fas fa-trash"></i></span>
          </a>
        </div>
      </nav>
    </div>
  </article>
</template>

<script>
export default {
  props: ['product'],
  methods: {
    getProductImage(product) {
      return require(`../assets/products/${product.imageSrc}`);
    }
  }
}
</script>
