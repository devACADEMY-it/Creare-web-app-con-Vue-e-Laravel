<template>
  <div class="card">
    <div class="card-image">
      <figure class="image">
        <img class="product-img" :src="getProductImage(product)" :alt="product.label">
      </figure>
    </div>
    <div class="card-content">
      <div class="media">
        <div class="media-content">
          <p class="title is-4">{{ product.label }}</p>
          <p class="subtitle is-6">{{ product.price }} €</p>
          <p class="subtitle is-6">Quantità: {{ product.inventory }}</p>
        </div>
      </div>
    </div>
    <footer class="card-footer">
      <a href="#" class="card-footer-item" @click="addToCart(product)">Aggiungi al carrello</a>
    </footer>
  </div>
</template>

<script>
export default {
  props: ['product'],
  emits: ['add-to-cart'],
  methods: {
    getProductImage(product) {
      return require(`../assets/products/${product.imageSrc}`);
    },
    addToCart(product) {
      this.$emit('add-to-cart', { product });
    }
  }
}
</script>

<style scoped>
.product-img {
  width: 150px;
  height: 150px;
  margin: 0 auto;
}
</style>
