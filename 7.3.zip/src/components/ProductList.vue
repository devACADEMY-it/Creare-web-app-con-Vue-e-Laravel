<template>
  <h1 class="title">I nostri prodotti</h1>

  <div class="columns is-multiline">
    <div
      class="column is-3"
      v-for="product in products"
      :key="product.id"
    >
      <Product :product="product" @addToCart="onAddToCart($event)"></Product>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import Product from "./Product";

export default {
  components: {Product},
  created() {
    this.$store.dispatch('products/getAllProducts');
  },
  computed: mapState({
    products: state => state.products.all
  }),
  methods: {
    onAddToCart({ product }) {
      console.log(product);
      this.$store.dispatch('cart/addProductToCart', product);
      console.log(this.$store.state.cart.items);
    }
  }
};
</script>
