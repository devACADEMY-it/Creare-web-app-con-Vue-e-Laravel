import shop from "../../api/shop"

const state = () => ({
  all: []
});

const mutations = {
  setProducts(state, products) {
    state.all = products;
  },
  incrementProductInventory(state, { id, value = 1 }) {
    const product = state.all.find(item => item.id === id);
    product.inventory += value;
  },
  decrementProductInventory(state, { id }) {
    const product = state.all.find(item => item.id === id);
    product.inventory--;
  },
};

const actions = {
  getAllProducts(context) {
    // Mocking API
    shop.getProducts((products) => {
      context.commit('setProducts', products)
    });
  }
};

const getters = {};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters,
}
