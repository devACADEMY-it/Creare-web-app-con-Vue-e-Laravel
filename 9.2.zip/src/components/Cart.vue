<template>
  <h1 class="title">CART</h1>

  <div class="columns is-multiline">
    <h1 class="title is-2">Total: {{ total }} €</h1>
    <div class="column is-12" v-for="product in products" :key="product.id">
      <CartElement :product="product"></CartElement>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue';
import { useStore } from 'vuex';
import CartElement from "./CartElement";

export default {
  components: { CartElement },
  setup() {
    const store = useStore();

    const products = computed(() => store.getters['cart/cartProducts']);
    const total = computed(() => store.getters['cart/cartTotalPrice']);

    return {
      products,
      total
    }
  },
  /*
  computed: {
    ...mapGetters('cart', {
      products: 'cartProducts',
      total: 'cartTotalPrice'
    })
  }*/
}
</script>
