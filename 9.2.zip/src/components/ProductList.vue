<template>
  <h1 class="title">I nostri prodotti</h1>

  <div class="columns is-multiline">
    <div
      class="column is-3"
      v-for="product in products"
      :key="product.id"
    >
      <Product :product="product" @addToCart="onAddToCart($event)"></Product>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue';
import { useStore } from 'vuex'
import Product from "./Product";

export default {
  components: {Product},
  setup() {
    const store = useStore();

    const products = computed(() => store.state.products.all);

    const onAddToCart = ({ product }) => store.dispatch('cart/addProductToCart', product);

    if (products.value.length === 0) {
      store.dispatch('products/getAllProducts');
    }

    return {
      products,
      onAddToCart
    }
  },
  /*
  created() {
    if (this.products.length === 0) {
      this.$store.dispatch('products/getAllProducts');
    }
  },
  computed: mapState({
    products: state => state.products.all
  }),
  methods: {
    onAddToCart({ product }) {
      this.$store.dispatch('cart/addProductToCart', product);
    }
  }*/
};
</script>
