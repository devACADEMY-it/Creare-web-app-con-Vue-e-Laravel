<template>
  <div class="container">
    <!-- Product List -->
    <ProductList />
  </div>
</template>

<script>
import ProductList from "./ProductList";

export default {
  components: {
    ProductList
  }
}
</script>
