<template>
  <section class="section">
    <div class="container">
      <nav class="navbar" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
          <a class="navbar-item" href="#">
            <img src="./assets/slow_store.png" alt="Slow Store" width="120">
          </a>

          <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="myNav">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
          </a>
        </div>

        <div id="myNav" class="navbar-menu">
          <div class="navbar-end">
            <div class="navbar-item">
              <button class="button is-info">
                <span class="icon is-large"><i class="fas fa-shopping-cart"></i></span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div class="container">
        <h1 class="title">Vue Store</h1>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
