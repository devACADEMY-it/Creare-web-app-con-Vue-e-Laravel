<template>
    <div class="card mt-4">
        <div class="card-header">Nuovo Post</div>

        <div class="card-body">
            <form>
                <div class="form-group">
                    <label for="title">Titolo</label>
                    <input
                        v-model="title"
                        class="form-control"
                        id="title"
                        type="text"
                        placeholder="Titolo del post"
                        required
                    >
                </div>
                <div class="form-group">
                    <label for="body">Contenuto</label>
                    <textarea
                        v-model="body"
                        class="form-control"
                        id="body"
                        rows="3"
                        required
                    ></textarea>
                </div>
                <div>
                    <el-upload
                        action="/"
                        list-type="picture-card"
                        :on-preview="handlePictureCardPreview"
                        :on-change="updateImageList"
                        :auto-upload="false"
                    >
                        <i class="el-icon-plus"></i>
                    </el-upload>
                    <el-dialog :visible.sync="dialogVisible">
                        <img width="100%" :src="dialogImageUrl" alt="">
                    </el-dialog>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <button type="button" class="btn btn-success" @click="createPost">
                Crea post
            </button>
        </div>
    </div>
</template>

<script>
  export default {
    data() {
      return {
        dialogImageUrl: '',
        dialogVisible: false,
        imageList: [],
        title: '',
        body: ''
      };
    },
    methods: {
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      },
      updateImageList(file) {
        this.imageList.push(file.raw);
      },
      createPost(e) {
        e.preventDefault();

        // Controllare i campi title, body e imageList

        let formData = new FormData();
        formData.append('title', this.title);
        formData.append('body', this.body);

        this.imageList.map((image, i) => {
          formData.append(`images[${i}]`, image);
        });

        axios.post('/post/create', formData, { headers: { 'Content-Type': 'multipart/form-data' }})
          .then(response => {
            this.title = '';
            this.body = '';
            this.imageList = [];
            this.dialogImageUrl = '';

            this.$store.dispatch('getAllPosts');
          });
      }
    }
  }
</script>

<style scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>
