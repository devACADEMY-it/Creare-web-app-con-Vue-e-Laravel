<template>
  <section class="section">
    <div class="container">
      <nav class="navbar" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
          <router-link to="/" class="navbar-item">
            <img src="./assets/slow_store.png" alt="Slow Store" width="120">
          </router-link>

          <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="myNav">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
          </a>
        </div>

        <div id="myNav" class="navbar-menu">
          <div class="navbar-end">
            <div class="navbar-item">
              <router-link to="/cart" class="button is-info">
                <span class="icon is-large"><i class="fas fa-shopping-cart"></i></span>
              </router-link>
            </div>
          </div>
        </div>
      </nav>

      <router-view></router-view>
    </div>
  </section>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
