<template>
  <div class="container">
    <h1 class="title">Vue Store</h1>

    <!-- Product List -->
    <ProductList />
  </div>
</template>

<script>
import ProductList from "./ProductList";

export default {
  components: {
    ProductList
  }
}
</script>
