<template>
  <h1 class="title">Product List</h1>

  <div class="columns">
    <div class="column is-3">
      <div class="card">
        <div class="card-image">
          <figure class="image">
            <img src="../assets/products/ciambella.png" alt="Ciambella">
          </figure>
        </div>
        <div class="card-content">
          <div class="media">
            <div class="media-content">
              <p class="title is-4">Ciambella</p>
              <p class="subtitle is-6">2.50 €</p>
            </div>
          </div>

          <div class="content">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Phasellus nec iaculis mauris. <a>@bulmaio</a>.
            <a href="#">#css</a> <a href="#">#responsive</a>
          </div>
        </div>
        <footer class="card-footer">
          <a href="#" class="card-footer-item">Aggiungi al carrello</a>
        </footer>
      </div>
    </div>
  </div>
</template>

<script>
import data from '../api/data.json'

export default {
  data() {
    return {
      products: JSON.parse(JSON.stringify(data))
    }
  }
}
</script>
