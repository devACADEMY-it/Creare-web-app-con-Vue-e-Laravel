const state = () => ({
  items: [],
  checkoutStatus: null
});

const mutations = {
  pushItemToCart(state, { id }) {
    state.items.push({
      id,
      quantity: 1
    });
  },
  incrementItemQuantity(state, { id }) {
    const cartItem = state.items.find(item => item.id === id);
    cartItem.quantity++;
  },
  decrementItemQuantity(state, { id }) {
    const cartItem = state.items.find(item => item.id === id);
    cartItem.quantity--;
  },
  setCartItems(state, { items }) {
    state.items = items;
  },
  setCheckoutStatus(state, status) {
    state.checkoutStatus = status;
  }
};

const actions = {
  addProductToCart(context, product) {
    const { state, commit } = context;
    if (product.inventory > 0) {
      const cartItem = state.items.find(item => item.id === product.id);
      if (!cartItem) {
        // Non è presente nel carrello
        commit('pushItemToCart', { id: product.id });
      } else {
        // Prodotto già nel carrello
        commit('incrementItemQuantity', { id: product.id });
      }

      commit('products/decrementProductInventory', { id: product.id }, { root: true })
    }
  },
  removeProductFromCart(context, { id }) {
    
  }
};

const getters = {};

export default {
  state,
  mutations,
  actions,
  getters
}
