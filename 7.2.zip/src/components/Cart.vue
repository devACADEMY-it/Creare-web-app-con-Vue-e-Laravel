<template>
  <h1 class="title">CART</h1>

  <div class="columns is-multiline">
    <h1 class="title is-2">Total: {{ total }} €</h1>
    <div class="column is-12" v-for="product in products" :key="product.id">
      <CartElement :product="product"></CartElement>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import CartElement from "./CartElement";

export default {
  components: { CartElement },
  computed: {
    ...mapGetters('cart', {
      products: 'cartProducts',
      total: 'cartTotalPrice'
    })
  },
}
</script>
