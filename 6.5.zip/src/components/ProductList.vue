<template>
  <h1 class="title">I nostri prodotti</h1>

  <div class="columns is-multiline">
    <div
      class="column is-3"
      v-for="product in products"
      :key="product.id"
    >
      <Product :product="product" @addToCart="onAddToCart($event)"></Product>
    </div>
  </div>
</template>

<script>
import Product from "./Product";

export default {
  components: {Product},
  created() {
    this.$store.dispatch('products/getAllProducts');
  },
  data() {
    return {
      products: []
    }
  },
  methods: {
    onAddToCart({ product }) {
      console.log(product);
      // dispatch di $store.addToCart
    }
  }
};
</script>
