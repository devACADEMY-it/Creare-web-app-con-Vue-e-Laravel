/*
const _products = [
  {
    "id": 1,
    "name": "donut",
    "label": "Ciambella",
    "imageSrc": "ciambella.png",
    "price": 2.5,
    "inventory": 10
  },
  {
    "id": 2,
    "name": "coke",
    "label": "Coca in bottiglia",
    "imageSrc": "coca.png",
    "price": 3,
    "inventory": 10
  },
  {
    "id": 3,
    "name": "coke2",
    "label": "Coca in lattina",
    "imageSrc": "coca_2.png",
    "price": 1.5,
    "inventory": 10
  },
  {
    "id": 4,
    "name": "chicken_thigh",
    "label": "Coscia di Pollo",
    "imageSrc": "coscia_pollo.png",
    "price": 4,
    "inventory": 10
  },
  {
    "id": 5,
    "name": "ice_cream",
    "label": "Gelato",
    "imageSrc": "gelato.png",
    "price": 3.5,
    "inventory": 10
  },
  {
    "id": 6,
    "name": "hamburger",
    "label": "Hamburger",
    "imageSrc": "hamburger.png",
    "price": 8,
    "inventory": 10
  },
  {
    "id": 7,
    "name": "hotdog",
    "label": "Hot Dog",
    "imageSrc": "hotdog.png",
    "price": 6,
    "inventory": 10
  },
  {
    "id": 8,
    "name": "fries",
    "label": "Patatine Fritte",
    "imageSrc": "patatinefritte.png",
    "price": 5,
    "inventory": 10
  },
  {
    "id": 9,
    "name": "pizza",
    "label": "Pizza",
    "imageSrc": "pizza.png",
    "price": 7,
    "inventory": 10
  },
  {
    "id": 10,
    "name": "sausage",
    "label": "Salsiccia",
    "imageSrc": "salsiccia.png",
    "price": 4,
    "inventory": 10
  },
  {
    "id": 11,
    "name": "tacos",
    "label": "Tacos",
    "imageSrc": "tacos.png",
    "price": 5,
    "inventory": 10
  },
  {
    "id": 12,
    "name": "wrap",
    "label": "Wrap",
    "imageSrc": "wrap.png",
    "price": 6.5,
    "inventory": 10
  }
];
*/

export default {
  async getProducts(cb) {
    //setTimeout(() => cb(_products), 100)
    const res = await fetch('http://127.0.0.1:8000/product');
    const result = await res.json();
    cb(result);
  }
}
