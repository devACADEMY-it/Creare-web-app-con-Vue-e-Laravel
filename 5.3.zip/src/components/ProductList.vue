<template>
  <h1 class="title">Product List</h1>
</template>

<script>
export default {

}
</script>
