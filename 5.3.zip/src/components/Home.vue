<template>
  <div class="container">
    <h1 class="title">Vue Store</h1>

    <!-- Product List -->
  </div>
</template>

<script>
  export default {

  }
</script>
