<template>
    <div class="row">
        <div class="col-md-6" v-for="(post, i) in posts" :key="i">
            <div class="card mt-4">
                <img v-if="post.post_images.length > 0" class="card-image-top" :src="getImagePath(post)" alt=""/>
                <div class="card-body">
                    <p class="card-text">
                        <strong>{{ post.title }}</strong><br/>
                        {{ truncateText(post.body) }}
                    </p>
                </div>
                <button class="btn btn-primary m-2" @click="showDetail(i)">Scopri di più</button>
            </div>
        </div>

        <el-dialog v-if="currentPost" :visible.sync="postDetailVisible" width="40%">
            <span>
                <h3>{{ currentPost.title }}</h3>
                <div class="row">
                    <div class="col-md-6" v-for="(postImage, i) in currentPost.post_images" :key="i">
                        <img class="img-thumbnail" :src="postImage.path" :alt="postImage.caption">
                    </div>
                </div>
                <hr>
                <p>{{ currentPost.body }}</p>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="postDetailVisible = false">Chiudi</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
  export default {
    async created() {
      await axios.get('/post/get_all')
        .then(response => {
            this.posts = response.data.data;
        })
        .catch(error => {
          console.log(error)
        });
    },
    data() {
      return {
        posts: [],
        currentPost: null,
        postDetailVisible: false
      };
    },
    methods: {
        getImagePath(post) {
          return post.post_images[0].path;
        },
        truncateText(body) {
            if (body.length > 30) {
              return `${body.substr(0, 30)} ...`;
            }
            return body;
        },
        showDetail(index) {
          this.currentPost = this.posts[index];
          this.postDetailVisible = true;
        }
    }
  }
</script>

<style scoped>
.card-image-top {
    height: 200px;
    width: auto;
}
</style>
